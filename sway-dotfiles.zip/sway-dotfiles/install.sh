#!/usr/bin/env bash
#
# install.sh - Instalador automático de dotfiles Sway/SwayFX para Debian 13
#
set -euo pipefail

DOTFILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/config"
BACKUP_DIR="$HOME/.config-backup-$(date +%Y%m%d-%H%M%S)"

log()  { echo -e "\e[1;32m[OK]\e[0m $*"; }
warn() { echo -e "\e[1;33m[AVISO]\e[0m $*"; }
err()  { echo -e "\e[1;31m[ERROR]\e[0m $*" >&2; }

if [[ $EUID -eq 0 ]]; then
    err "No ejecutes este script como root. Ejecútalo como tu usuario normal (usará sudo cuando lo necesite)."
    exit 1
fi

command -v sudo >/dev/null 2>&1 || { err "Necesitas 'sudo' instalado."; exit 1; }

echo "=================================================="
echo " Instalador de dotfiles Sway/SwayFX - Debian 13"
echo "=================================================="
echo

# ---------------------------------------------------------------------------
# 1. Comprobar SwayFX vs Sway normal
# ---------------------------------------------------------------------------
USE_SWAYFX=false
read -rp "¿Quieres intentar instalar SwayFX (efectos visuales tipo Hyprland: blur, sombras, bordes redondeados)? [s/N]: " resp
if [[ "$resp" =~ ^[sS]$ ]]; then
    USE_SWAYFX=true
fi

# ---------------------------------------------------------------------------
# 2. Paquetes base
# ---------------------------------------------------------------------------
log "Actualizando índices de apt..."
sudo apt update

BASE_PKGS=(
    sway
    waybar
    wofi
    kitty
    firefox-esr
    nautilus
    swaylock
    swayidle
    swaybg
    grim
    slurp
    wl-clipboard
    xdg-desktop-portal-wlr
    network-manager
    network-manager-gnome
    pipewire
    pipewire-pulse
    wireplumber
    pavucontrol
    brightnessctl
    policykit-1-gnome
    fonts-noto-color-emoji
    imagemagick
    unzip
    curl
    git
)

log "Instalando paquetes base (esto puede tardar)..."
sudo apt install -y "${BASE_PKGS[@]}" || {
    warn "Algún paquete falló. Revisa arriba: puede que 'firefox-esr' o 'nautilus' tengan otro nombre en tu repo."
}

# ---------------------------------------------------------------------------
# 2b. Nerd Font (JetBrainsMono). Debian NO trae la versión parcheada con
#     iconos en sus repos, así que se descarga directamente del proyecto
#     Nerd Fonts. Sin esto, Waybar/Wofi mostrarán cuadros en vez de iconos.
# ---------------------------------------------------------------------------
FONT_DIR="$HOME/.local/share/fonts"
if fc-list 2>/dev/null | grep -qi "JetBrainsMono Nerd Font"; then
    log "JetBrainsMono Nerd Font ya está instalada."
else
    log "Descargando JetBrainsMono Nerd Font..."
    NF_VERSION="$(curl -fsSL https://api.github.com/repos/ryanoasis/nerd-fonts/releases/latest 2>/dev/null | grep -m1 '"tag_name"' | cut -d'"' -f4 || true)"
    NF_VERSION="${NF_VERSION:-v3.2.1}"
    mkdir -p "$FONT_DIR"
    TMP_FONT="$(mktemp -d)"
    if curl -fsSL -o "$TMP_FONT/JetBrainsMono.zip" \
        "https://github.com/ryanoasis/nerd-fonts/releases/download/${NF_VERSION}/JetBrainsMono.zip"; then
        unzip -oq "$TMP_FONT/JetBrainsMono.zip" -d "$FONT_DIR"
        fc-cache -f "$FONT_DIR" >/dev/null 2>&1
        log "Fuente instalada en $FONT_DIR"
    else
        warn "No se pudo descargar la Nerd Font automáticamente. Instálala a mano desde:"
        warn "https://github.com/ryanoasis/nerd-fonts/releases (paquete JetBrainsMono.zip)"
    fi
    rm -rf "$TMP_FONT"
fi

# ---------------------------------------------------------------------------
# 3. SwayFX (opcional). Debian no lo trae en repos oficiales,
#    así que si el usuario lo pide se compila desde código fuente.
# ---------------------------------------------------------------------------
if $USE_SWAYFX; then
    if command -v swayfx >/dev/null 2>&1; then
        log "SwayFX ya está instalado."
    else
        warn "SwayFX no está en los repos de Debian. Se compilará desde el código fuente."
        warn "Esto instalará dependencias de compilación y puede tardar varios minutos."
        sudo apt install -y meson ninja-build cmake pkg-config \
            libwlroots-dev libwayland-dev wayland-protocols \
            libxkbcommon-dev libpixman-1-dev libcairo2-dev libpango1.0-dev \
            libjson-c-dev libgdk-pixbuf2.0-dev scdoc libinput-dev \
            libseat-dev libdrm-dev libpam0g-dev libsystemd-dev || \
            warn "Faltan dependencias de compilación; puede que la build de SwayFX falle."

        TMP_BUILD="$(mktemp -d)"
        git clone --depth 1 https://github.com/WillPower3309/swayfx "$TMP_BUILD/swayfx" || {
            err "No se pudo clonar SwayFX. Revisa tu conexión o compila manualmente más tarde."
            USE_SWAYFX=false
        }
        if $USE_SWAYFX; then
            (
                cd "$TMP_BUILD/swayfx"
                meson setup build --prefix=/usr/local
                ninja -C build
                sudo ninja -C build install
            ) && log "SwayFX compilado e instalado en /usr/local/bin" || {
                err "La compilación de SwayFX falló. Usarás Sway normal (sin blur/sombras, pero funcional)."
                USE_SWAYFX=false
            }
        fi
    fi
fi

# ---------------------------------------------------------------------------
# 4. Copiar dotfiles con backup de lo existente
# ---------------------------------------------------------------------------
mkdir -p "$BACKUP_DIR"
for app in sway waybar wofi kitty; do
    if [[ -d "$HOME/.config/$app" ]]; then
        log "Haciendo backup de ~/.config/$app en $BACKUP_DIR/"
        mv "$HOME/.config/$app" "$BACKUP_DIR/"
    fi
    mkdir -p "$HOME/.config/$app"
    cp -r "$DOTFILES_DIR/$app/." "$HOME/.config/$app/"
    log "Copiado $app -> ~/.config/$app"
done

# ---------------------------------------------------------------------------
# 5. Wallpaper: si no tienes uno, se genera automáticamente un degradado
#    con el mismo tema Catppuccin Mocha que usa el resto de dotfiles.
# ---------------------------------------------------------------------------
if [[ ! -f "$HOME/.config/sway/wallpaper.jpg" ]]; then
    if command -v convert >/dev/null 2>&1; then
        log "Generando wallpaper por defecto (degradado Catppuccin Mocha)..."
        convert -size 1920x1080 gradient:'#1e1e2e'-'#313244' "$HOME/.config/sway/wallpaper.jpg"
        log "Wallpaper generado en ~/.config/sway/wallpaper.jpg"
        warn "Cámbialo cuando quieras: sustituye ese archivo por tu imagen favorita."
    else
        warn "No hay wallpaper.jpg y no se pudo generar uno (falta imagemagick)."
        warn "Coloca tu imagen favorita en ~/.config/sway/wallpaper.jpg"
    fi
fi

# ---------------------------------------------------------------------------
# 5b. Permisos para brillo (brightnessctl) e input sin sudo
# ---------------------------------------------------------------------------
for grp in video input; do
    if getent group "$grp" >/dev/null 2>&1; then
        sudo usermod -aG "$grp" "$USER" && log "Añadido $USER al grupo '$grp'."
    fi
done
warn "Cierra sesión y vuelve a entrar para que los grupos nuevos surtan efecto."

# ---------------------------------------------------------------------------
# 6. NetworkManager activo (para el módulo wifi de Waybar)
# ---------------------------------------------------------------------------
if command -v systemctl >/dev/null 2>&1; then
    sudo systemctl enable --now NetworkManager || warn "No se pudo activar NetworkManager automáticamente."
fi

# ---------------------------------------------------------------------------
# 7. Sesión de login (entrada en /usr/share/wayland-sessions)
# ---------------------------------------------------------------------------
SESSION_CMD="sway"
if $USE_SWAYFX && command -v swayfx >/dev/null 2>&1; then
    SESSION_CMD="swayfx"
fi

if [[ -f /usr/share/wayland-sessions/sway.desktop || -f /usr/share/wayland-sessions/labwc.desktop ]] || dpkg -l | grep -qE 'gdm3|sddm|lightdm'; then
    log "Tienes un gestor de login gráfico. Elige la sesión '$SESSION_CMD' en la pantalla de login."
else
    warn "No se detectó ningún gestor de login gráfico (GDM/SDDM/LightDM)."
    read -rp "¿Quieres que $SESSION_CMD arranque automáticamente al iniciar sesión en la TTY? [s/N]: " tty_resp
    if [[ "$tty_resp" =~ ^[sS]$ ]]; then
        PROFILE_LINE="if [[ -z \$WAYLAND_DISPLAY && \$(tty) == /dev/tty1 ]]; then exec $SESSION_CMD; fi"
        if ! grep -qF "$SESSION_CMD" "$HOME/.bash_profile" 2>/dev/null; then
            echo "$PROFILE_LINE" >> "$HOME/.bash_profile"
            log "Añadido a ~/.bash_profile: arrancará $SESSION_CMD al hacer login en tty1."
        else
            warn "~/.bash_profile ya tiene una referencia a $SESSION_CMD, no se ha tocado."
        fi
    fi
fi

echo
log "¡Instalación completada!"
echo "Backup de tu configuración anterior (si existía): $BACKUP_DIR"
echo
echo "Atajos configurados:"
echo "  Super sola          -> abre el launcher (wofi)"
echo "  Super + T           -> abre kitty"
echo "  Super + E           -> abre el explorador de archivos (nautilus)"
echo "  Super + W           -> abre Firefox"
echo "  Super + 1..0        -> cambiar de workspace"
echo "  Super + Ctrl + Flechas -> workspace siguiente/anterior"
echo
warn "Nota: Sway (incluso con SwayFX) NO anima el deslizamiento entre workspaces como Hyprland."
warn "Es una limitación del compositor, no de esta configuración."
